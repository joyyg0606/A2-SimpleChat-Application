package edu.seg2105.client.ui;
// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.*;
import java.util.Scanner;

import edu.seg2105.client.backend.ChatClient;
import edu.seg2105.client.common.*;

/**
 * This class constructs the UI for a chat client.  It implements the
 * chat interface in order to activate the display() method.
 * Warning: Some of the code here is cloned in ServerConsole 
 *
 * @author François Bélanger
 * @author Dr Timothy C. Lethbridge  
 * @author Dr Robert Laganière
 */
public class ClientConsole implements ChatIF 
{
  //Class variables ***********************************************

  final public static int DEFAULT_PORT = 5555;

  //Instance variables ********************************************

  ChatClient client;

  /**
   * Scanner to read from the console
   */
  Scanner fromConsole; 

  //Constructors **************************************************

  /**
   * Constructs an instance of the ClientConsole UI.
   *
   * @param loginId The login ID for this client.
   * @param host The host to connect to.
   * @param port The port to connect on.
   */
  public ClientConsole(String loginId, String host, int port) 
  {
    try 
    {
      client = new ChatClient(loginId, host, port, this);
    } 
    catch(IOException exception) 
    {
      System.out.println("Error: Can't setup connection! Terminating client.");
      System.exit(1);
    }

    fromConsole = new Scanner(System.in); 
  }

  //Instance methods **********************************************

  public void accept() 
  {
    try
    {
      String message;

      while (true) 
      {
        message = fromConsole.nextLine();
        client.handleMessageFromClientUI(message);
      }
    } 
    catch (Exception ex) 
    {
      System.out.println("Unexpected error while reading from console!");
    }
  }

  /**
   * This method overrides the method in the ChatIF interface.  
   * It displays a message onto the screen.
   *
   * @param message The string to be displayed.
   */
  public void display(String message) 
  {
    System.out.println("> " + message);
  }

  //Class methods ***************************************************

  /**
   *
   * @param args Command line arguments: 
   *        args[0] = loginId, args[1] = host name (optional), args[2] = port number (optional)
   */
  public static void main(String[] args) 
  {
    if(args.length < 1) {
        System.out.println("Usage: java ClientConsole <loginId> [host] [port]");
        System.exit(1);
    }

    String loginId = args[0];
    String host = (args.length > 1) ? args[1] : "localhost";
    int port = (args.length > 2) ? Integer.parseInt(args[2]) : DEFAULT_PORT;

    ClientConsole chat = new ClientConsole(loginId, host, port);
    chat.accept();
  }
}
