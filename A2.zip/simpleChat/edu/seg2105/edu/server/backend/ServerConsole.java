package edu.seg2105.edu.server.backend;

import java.util.Scanner;
import edu.seg2105.edu.server.backend.EchoServer;
import edu.seg2105.client.common.ChatIF;

/**
 * this class allows the server user to type messages.
 */
public class ServerConsole implements ChatIF {
    private EchoServer server;
    private Scanner fromConsole;

    public ServerConsole(EchoServer server) {
        this.server = server;
        fromConsole = new Scanner(System.in);
    }

    public void accept() {
        try {
            String message;
            while(true) {
                message = fromConsole.nextLine();
                if(message.startsWith("#")) {
                    String[] tokens = message.split(" ", 2);
                    String command = tokens[0];

                    switch(command) {
                        case "#quit":
                            server.close();
                            System.exit(0);
                            break;

                        case "#stop":
                            server.stopListening();
                            System.out.println("Server stopped listening for new clients.");
                            break;

                        case "#close":
                            server.close();
                            System.out.println("Server closed.");
                            break;

                        case "#setport":
                            if(server.isListening()) {
                                System.out.println("Cannot set port while server is running. Stop server first.");
                            } else if(tokens.length > 1) {
                                try {
                                    server.setPort(Integer.parseInt(tokens[1]));
                                    System.out.println("Port set to " + tokens[1]);
                                } catch(NumberFormatException e) {
                                    System.out.println("Invalid port number.");
                                }
                            } else {
                                System.out.println("Usage: #setport <port>");
                            }
                            break;

                        case "#start":
                            if(!server.isListening()) {
                                try {
                                    server.listen();
                                } catch(Exception e) {
                                    System.out.println("Error starting server.");
                                }
                            } else {
                                System.out.println("Server is already listening.");
                            }
                            break;

                        case "#getport":
                            System.out.println("Current port: " + server.getPort());
                            break;

                        default:
                            System.out.println("Unknown command: " + command);
                    }
                } else {
                    server.sendToAllClients("SERVER MSG> " + message);
                    System.out.println("SERVER MSG> " + message);
                }
            }
        } catch(Exception e) {
            System.out.println("Unexpected error in server console.");
        }
    }

    @Override
    public void display(String message) {
        System.out.println(message);
    }
}